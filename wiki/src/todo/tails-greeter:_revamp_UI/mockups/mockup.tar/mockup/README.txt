
To test mockups:

    $ ./mockup.py [-v <variant>] [-p]

Options:

    -v <variant>    use <variant> where variant is the number of the .ui file
    -p              act as if booted from USB with persistence
